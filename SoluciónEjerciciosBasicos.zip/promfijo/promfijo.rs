
fn main(){
   let prom:i32=(19+17+21+9+12+7)/6;
   println!("El promedio es: {}",prom);
}
