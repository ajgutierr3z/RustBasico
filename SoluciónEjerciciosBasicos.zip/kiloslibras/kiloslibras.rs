use std::io;
fn main(){
   let mut k=String::new();
   let stdin=io::stdin();
   println!("Introdusca el valor de kilogramos a convertir en libras");
   stdin.read_line(&mut k).expect("Error al leer");
   let ki:f32=k.trim().parse().unwrap();
   let libra:f32= ki*2.2;
   println!("{} kilogramos en libra es: {}",k,libra);
}
