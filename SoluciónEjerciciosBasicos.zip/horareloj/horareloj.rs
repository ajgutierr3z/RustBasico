use std::io;
fn main(){
    let mut t = String::new();
    let mut h = String::new();
    let stdin=io::stdin();
    println!("Introduce el valor entero de la hora actual:");
    stdin.read_line(&mut t).expect("Error al leer");
    println!("Introduce una cantidad de horas: ");
    stdin.read_line(&mut h).expect("Error al leer");
    let ti:i32 = t.trim().parse().unwrap();
    let ho:i32 = h.trim().parse().unwrap();
    let total:i32 = ti+ho;
    println!("En {} horas, el reloj marcara las {} horas. ",h,total);
}
