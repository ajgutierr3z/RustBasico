use std::io;
fn main(){
  let mut ca = String::new();
  let mut co = String::new();
  let stdin=io::stdin();
  println!("Introduce el valor del cateto a");
  stdin.read_line(&mut ca).expect("Error al leer");
  println!("Introduce el valor del cateto b");
  stdin.read_line(&mut co).expect("Error al leer");
  let mut hip:f32=ca.trim().parse().unwrap();
  let mut cop:f32=co.trim().parse().unwrap();
  hip= hip * hip;
  cop = cop * cop;
  let hipo:f32;
  hipo = hip + cop;
  let hipot:f32;
  hipot = hipo.powf(1.0/2.0);
  println!("la hipotenusa es: {}", hipot);
}
