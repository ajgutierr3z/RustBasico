use std::io;
fn main(){
   let mut base=String::new();
   let mut altura=String::new();
   let stdin=io::stdin();
   println!("Introduce el valor de la base del triángulo");
   stdin.read_line(&mut base).expect("Error al leer");
   println!("Introduce el valor de la altura del triángulo");
   stdin.read_line(&mut altura).expect("Error a leer");
   let b:i32=base.trim().parse().unwrap();
   let a:i32=base.trim().parse().unwrap();
   let area:i32=(b*a)/2;
   println!("El área del triángulo es: {}",area)
}
