use std::io;
fn main(){
  let mut ht = String::new();
  let stdin=io::stdin();
  println!("¿Cuántas horas trabajo? 80hr = 15a");
  stdin.read_line(&mut ht).expect("Error al leer");
  let hot:f32=ht.trim().parse().unwrap();
  let sal:f32=hot*50.0;
  let com:f32=sal*0.02;
  let salcom:f32= sal + com;
  let ims:f32=salcom*0.015;
  let ispt:f32=salcom*0.012;
  let salnet:f32=salcom - (ims+ispt);
  println!("Pago de horas trabajadas: {}",sal);
  println!("pago de compensación: {}",com);
  println!("Descuento IMSS: {}",ims);
  println!("Descuento ISPT: {}",ispt);
  println!("Salario neto: {}",salnet);
}
