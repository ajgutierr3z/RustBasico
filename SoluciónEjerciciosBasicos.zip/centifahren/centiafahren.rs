use std::io;
fn main(){
   let mut cent = String::new();
   let stdin=io::stdin();
   println!("Introduce la cantidad de gradas centigrados a convertir a 
fahrenheit");
   stdin.read_line(&mut cent).expect("Error al leer");
   let centi:f32=cent.trim().parse().unwrap();
   let fahren:f32 = (centi*1.8000) + 32.00;
   println!("Los {} grados centigrados son: {} grados 
fahrenheit",cent,fahren);
}
