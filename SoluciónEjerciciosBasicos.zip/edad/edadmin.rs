use std::io;
fn main(){
   let mut edad=String::new();
   let stdin=io::stdin();
   println!("Introduce tu edad");
   stdin.read_line(&mut edad).expect("Error al leer");
   let ed:i32=edad.trim().parse().unwrap();
   let decadas:i32 = ed / 10;
   let lustro:i32 = ed /5;
   let mes:i32= ed * 12;
   let sem:i32= ed*52;
   let dias:i32=ed*365;
   let horas:i32=dias*24;
   let minutos:i32=horas*60;
   println!("Decadas: {}, lustros: {}, años: {}, meses: {}, semanas: {},  
 días: {}, horas: {}, minutos: {}", decadas,lustro,ed,mes,sem,dias,horas,minutos);
}
