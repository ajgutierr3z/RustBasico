//primer programa en rust
fn main() {
    println! ("¡hola mundo en rust!");
}
