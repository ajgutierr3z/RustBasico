use std::io;
fn main(){
   let mut pies=String::new();
   let stdin=io::stdin();
   println!("Introduce el número de pulgadas a convertir a metros");
   stdin.read_line(&mut pies).expect("Error al leer");
   let pie:f32=pies.trim().parse().unwrap();
   let mts:f32= pie/39.370;
   println!("{} pies son {} metros",pie,mts);
}
