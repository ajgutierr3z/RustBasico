use std::io;
fn main(){
   let mut c1=String::new();
   let mut c2=String::new();
   let mut c3=String::new();
   let mut c4=String::new(); 
   let stdin=io::stdin();
   println!("Introduce la primera calificación:");
   stdin.read_line(&mut c1).expect("Error al leer");
   println!("Introduce la segunda calificación: ");
   stdin.read_line(&mut c2).expect("Error al leer");
   println!("Introduce la tercera califiacion: ");
   stdin.read_line(&mut c3).expect("Error al leer");
   println!("Introduce la última calificación: ");
   stdin.read_line(&mut c4).expect("error al leer");
   let ca1:f32 = c1.trim().parse().unwrap();
   let ca2:f32 = c2.trim().parse().unwrap();
   let ca3:f32 = c3.trim().parse().unwrap();
   let ca4:f32 = c4.trim().parse().unwrap();
   let mut promedio:f32 = ca1+ca2+ca3+ca4;
   promedio = promedio /4.0;
   println!("El promedio es: {}",promedio);
}
