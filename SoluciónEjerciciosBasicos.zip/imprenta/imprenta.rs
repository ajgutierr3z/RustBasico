fn main(){
   println!("AAAAAAAAAAAAA");
   println!("     A      A");
   println!("     A      A");
   println!("     A      A");
   println!("AAAAAAAAAAAAA");
   println!("  JJJJJ      ");
   println!("  J          ");
   println!("  J          ");
   println!("  J          ");
   println!("  JJJJJJJJJJJ");
}
