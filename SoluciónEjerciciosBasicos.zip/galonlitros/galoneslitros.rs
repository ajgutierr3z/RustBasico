use std::io;
fn main(){
   let mut gal=String::new();
   let stdin=io::stdin();
   println!("Introduce la cantidad de galones a convertir en litros");
   stdin.read_line(&mut gal).expect("Error al leer");
   let galo:f32 = gal.trim().parse().unwrap();
   let litro:f32 = galo/0.21997;
   println!("Los {} galones son {} litros",gal,litro);
}
