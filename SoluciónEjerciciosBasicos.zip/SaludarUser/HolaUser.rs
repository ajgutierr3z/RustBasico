use std::io;

fn main (){
   let mut nombre = String::new(); 
   let stdin = io::stdin();
   println!("¿Cómo te llamas?");
   stdin.read_line(&mut nombre).expect("error al leer");
    println!("Hola {}",nombre);
}
