use std::io;
fn main(){
   let mut pies=String::new();
   let stdin=io::stdin();
   println!("Introduce el número de pies a convertir a metros");
   stdin.read_line(&mut pies).expect("Error al leer");
   let pis:f32=pies.trim().parse().unwrap();
   let mts:f32 = pis/3.2808;
   println!("{} pies son {} metros",pies, mts); 
}
