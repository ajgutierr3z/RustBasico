use std::io;
fn main(){
    let mut radio = String:: new();
    let stdin =io::stdin();
    println!("Introduce el valor del radio");
    stdin.read_line(&mut radio).expect("error al leer");
    let perimetro:f32;
    let mut area:f32;
    let r:f32 = radio.trim().parse().unwrap();
    perimetro = 2.0*3.1415*r;
    area =r*r;
    area = area * 3.1416;
    println!("El perimetro del circulo es: {}",perimetro);
    println!("El área del circulo es: {}", area);
}
