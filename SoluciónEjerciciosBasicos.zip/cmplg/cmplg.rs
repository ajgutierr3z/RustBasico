use std::io;
fn main(){
   let mut cm = String::new();
   let stdin=io::stdin();
   println!("Introduce los centimentros a convertir en pulgadas");
   stdin.read_line(&mut cm).expect("Error al leer");
   let cmt:f32= cm.trim().parse().unwrap();
   let pul=cmt / 2.55;
   println!("Los {} centimetros son: {} pulgadas",cm,pul);
}
