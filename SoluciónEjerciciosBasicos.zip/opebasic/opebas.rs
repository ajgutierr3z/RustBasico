use std::io;
fn main(){
   let mut n1=String::new();
   let mut n2=String::new();
   let stdin=io::stdin();
   println!("Introduce el primer valor entero");
   stdin.read_line(&mut n1).expect("Error al leer");
   println!("Introduce el segundo valor entero");
   stdin.read_line(&mut n2).expect("Error al leer");
   let nu1:i32=n1.trim().parse().unwrap();
   let nu2:i32=n2.trim().parse().unwrap();
   let sum:i32=nu1+nu2;
   let res:i32=nu1+nu2;
   let div:i32=nu1/nu2;
   let mul:i32=nu1*nu2;
   println!("La suma es: {}, la resta es: {}, la multiplicación es: {}, 
la división es: {}",sum,res,mul,div);
}
