use std::io;
fn main(){
   let mut pies = String::new();
   let stdin=io::stdin();
   println!("Introduce la cantidad de pies a convertir en pulgadas");
   stdin.read_line(&mut pies).expect("Error al leer");
   let pie:f32=pies.trim().parse().unwrap();
   let pulga:f32= pie*12.000;
   println!("Los {} pies son {} pulgadas",pies,pulga);
}
