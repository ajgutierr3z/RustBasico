use std::io;
fn main(){
   let mut lado=String::new();
   let stdin=io::stdin();
   println!("Esctibe el valor de un lado del cuadrado");
   stdin.read_line(&mut lado).expect("Error al leer");
   let l:i32=lado.trim().parse().unwrap();
   let area:i32 = l*l;
   let perimetro:i32=l*4;
   println!("El área del cuadrado es: {}. El perímetro del cuadrado es: 
{}",area, perimetro);
}
